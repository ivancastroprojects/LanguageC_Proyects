#include <stdio.h>
#include <stdlib.h>
#include <math.h>

float media(vector);
float varianza(vector, media);
float desviacion(varianza);

////////////////////////////////////////////////////////////


int main() {
    int i;
    int vec_numeros[15];
    printf("Introduzca 15 números\n");

    for(i=0; i<vec_numeros[i]; i++) {
        scanf("%d", &vec_numeros[i]);
    }

    media(vec_numeros);
    varianza(vec_numeros, media(vec_numeros));
    desviacion(varianza(vec_numeros));

    return 0;
}

///////////////////////////////////////////////////////////

float media(vector) {
    float v_media;
    int i, suma;
    for(i=0; i<vector[i].length; i++) {
        suma = suma + vector[i];
    }
    return v_media = suma/15;
}

float varianza(vector, media) {
    float v_varianza;
    int i;
    float suma;
    for(i=0; i<vector[i].length; i++) {
        suma += suma + pow(vector[i], 2);
    }
    return v_varianza = (suma-pow(media, 2))/15;
}

float desviacion(varianza) {
    float v_desviacion;
    return v_desviacion = sqrt(varianza);
}
