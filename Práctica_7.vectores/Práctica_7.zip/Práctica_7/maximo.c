#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void inicializa(int vector);
int maximo(int vector);

////////////////////////////////////////////////////////////


int main(){
    int vector_numeros[10];

    inicializa(vector_numeros);
    maximo(vector_numeros);

    return 0;
}

///////////////////////////////////////////////////////////


void inicializa(int vector) {
    printf("Escribe 10 números: \n");

    int i;
    for(i = 0; i < vector; i++)
    {
        scanf("%d", &vector[i]);
    }
    printf("\nVector inicializado con los números solicitados.");
}


int maximo(int vector) {
    int i, max = 0;
    for(i = 0; i < vector; i++) {
        if(vector[i] > max)
            max = vector[i];
    }
    return max;
}

