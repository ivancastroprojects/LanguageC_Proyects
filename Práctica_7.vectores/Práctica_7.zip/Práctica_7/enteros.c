#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int enteros(int vector, int tipo);

////////////////////////////////////////////////////////////

int main() {
    int i;
    int vec_numeros[20];
    int tipo_numero[3]; //0 Negativos, 1 Ceros, 2 Positivos
    printf("Introduzca 20 números enteros (positivos, negativos o 0): \n");

    for(i=0; i<vec_numeros[i]; i++) {
        scanf("%d", &vec_numeros[i]);
    }

    enteros(vec_numeros, tipo_numero);
    
    printf("\nHay %d números positivos, %d ceros y %d números negativos.", tipo_numero[0], tipo_numero[1], tipo_numero[2]);

    return 0;
}

int enteros(int vector, int tipo) {
    int i;
    int positivos=0, negativos=0, ceros=0;
    for(i=0; i<vector[i].length; i++)
    {
        if(vector[i]<0)
            tipo[0] += 1;  //Negativos +1
        else if(vector[i]=0)
            tipo[1] += 1;  //Ceros +1
        else if(vector[i]>0)
            tipo[2] += 1;  //Positivos +1
    }
    return tipo;
}