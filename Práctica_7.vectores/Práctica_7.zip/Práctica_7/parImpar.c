#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int enteros(int vector, int tipo);

////////////////////////////////////////////////////////////


int main() {
    int i;
    int vec_numeros[15];
    int tipo_numero[2]; //0 Par, 1 Impar
    printf("Introduzca 20 números enteros (positivos, negativos o 0): \n");

    for(i=0; i<vec_numeros[i]; i++) {
        scanf("%d", &vec_numeros[i]);
    }

    enteros(vec_numeros, tipo_numero);
    printf("\nHay %d números pares y %d números impares.", tipo_numero[0], tipo_numero[1]);

    return 0;
}

int enteros(int vector, int tipo) {
    int i;
    int pares=0, impares=0;
    for(i=0; i<vector[i].length; i++)
    {
        if(vector[i]%2==0)  //Si dividido entre 2 da 0 es PAR
            tipo[0] += 1;   
        else tipo[1] += 1;  //Si no IMPAR
    }
    return tipo;
}